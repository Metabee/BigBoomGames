﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/*
*Developer:
*Andrés Darío Serna Isaza
*/

[DisallowMultipleComponent]

[ExecuteInEditMode]

public class CircleTransform :MonoBehaviour
{
	[SerializeField]
	private Vector3 center;

	public Vector3 P_center
	{
		get
		{
			return center;
		}
		set
		{
			center = value;

            centerofVerification = center;
		}
	}

    Vector3 centerofVerification = new Vector3(0, 0, 0);

    [Header("Polar coordinates: ")]
	[SerializeField]
	private float radio;   

	public float P_radio
	{
		get
		{ 
			return radio;
		}
		set
		{
			SetCoordinates(value, angle);
		}
	}
	[SerializeField]
	[Range(0,360)]
	private float angle;

	public float P_angle
	{
		get
		{ 
			return angle;
		}
		set
		{
			SetCoordinates(radio, value);
		}
	}

	float newDegrees;

	private void OnValidate()
	{
        if (center == centerofVerification)
        {
            SetCoordinates(radio, angle);
        }
        else
        {
            centerofVerification = center;
        }
	}
	// Update is called once per frame
	private void Update ()
	{
		// Radio
	    radio = GetRadio (center);
		// Angle
		angle = GetAngle (center);
	}	
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.green;
		Gizmos.DrawLine (center,transform.position);
	}

    // Polar Methods
	private void SetCoordinates(float radio, float angle)
	{
		float degrees = (angle * Mathf.PI) / 180;
		float x = radio * Mathf.Cos (degrees) + center.x;
		float y = radio * Mathf.Sin (degrees) + center.y;
		transform.position = new Vector3 (x, y, transform.position.z);
	}
	public float GetRadio(Vector2 center)
	{
		float distancia = Mathf.Sqrt(Mathf.Pow(transform.position.x - center.x,2) + 
			                         Mathf.Pow(transform.position.y - center.y,2));
		return distancia;
	}
	public float GetAngle(Vector2 center)
	{
		float realAngle;

		if (radio != 0) 
		{

			newDegrees = Mathf.Atan ((transform.position.y - center.y) / 
				(transform.position.x - center.x));
			/*
			 * Cuadrante 1 = +
			 * Cuadrante 2 = -
			 * Cuadrante 3 = +
			 * Cuadrante 4 = -
			*/
			if (transform.position.x >= center.x && 
				transform.position.y >= center.y)
			{
				realAngle = (newDegrees * 180) / Mathf.PI;	
			}
			else if (transform.position.x < center.x) 
			{
				realAngle = 180 + ((newDegrees * 180) / Mathf.PI);
			} 
			else 
			{
				realAngle = 360 + ((newDegrees * 180) / Mathf.PI);
			}
		} 
		else
		{
			realAngle = 0;
		}

		return realAngle;
	}
}

